def print_modules(a):
    x=" "
    a=a+x
    return a
