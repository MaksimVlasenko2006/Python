def animal(kind,name):
    a=f'У меня есть {kind} и его кличка "{name.title()}"'
    return a
