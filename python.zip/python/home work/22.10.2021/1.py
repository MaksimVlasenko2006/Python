while True:
	car = input('Какую машину вы хотите взять на прокат?   ')
	if car == 'stop':
		print('Ок, я прекращаю.')
		break
	else:
		print(f'Дай-ка посмотреть найдули я {car}')
