#7.7
k=2
while k>1:
    k+=1
    print(k)