name = input('Name ')
print(f'\n{name}')
