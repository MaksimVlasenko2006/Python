prompt = 'Мне нужно немного информации о Вас'
prompt += '\nСкажи пожалуйста, как тебя зовут? '
name = input(prompt)
print(f'\nHello, {name}')
