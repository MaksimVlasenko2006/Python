while True:
    name = input('Введите имя: ')
    if name =='Хватит':
        break
    print('Привет,', name)
