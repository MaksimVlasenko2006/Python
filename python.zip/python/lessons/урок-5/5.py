a = int(input('Введите первое число   '))
if a > 15:
    a = a + 7
else:
    a = a - 5
print(a)
