class Animal:
    pass
p1=Animal()
p1.name="Stas"
p1.surname="Matveychuk"
p1.age="15"
p1.place_of_bieth="UA"
print(f"\n name:{p1.name}\n surname:{p1.surname}\n age:{p1.age}\n place_of_bieth:{p1.place_of_bieth}\n")
p2=Animal
p2.name="Yarik"
p2.surname="Vigovskiy"
p2.age="14"
p2.place_of_bieth="UA"
print(f"\n name:{p2.name}\n surname:{p2.surname}\n age:{p2.age}\n place_of_bieth:{p2.place_of_bieth}\n")
