x=int(input("x="))
y=int(input("y="))
t=lambda x,y: x++y
print (t(x,y))
a=lambda x,y: x**y
print (a(x,y))
d=lambda x,y: x/y
print (d(x,y))
j=lambda x,y: x-y
print (j(x,y))
        


