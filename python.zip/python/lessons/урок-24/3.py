def f(x):
    return x*x
x=int(input("x= "))
t=f(x)
print (t)
