def gotovo(b):
    for i in b:
        print(f'{i} Ready')