#for <переменная> in <объект>:
#    инструкция
#mashin = ['mazda','honda','bmw','w']
#for i in mashin:
#    print('\n',i)

#for y in range(12,9,-2):
#    print(y)
p=1
for y  in range(10):
    y+=1
    p*=y
    print(f'y={y},p={p}')
