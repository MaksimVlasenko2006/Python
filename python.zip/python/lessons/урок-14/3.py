dictName={'Illia':18, 'Maksym':20, 'Den':24, 'Roma':7}
print(dictName['Maksym'])
print(dictName.values())
for i, j in dictName.items():
    print(f"{i}'s age - {j}")