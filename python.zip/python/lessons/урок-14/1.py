auto = ('waz', 'ferrari', 'kia', 'zigool', 'lambo', 25, 78)
print (auto)
print (auto[0], auto[1])
print (auto[-1])
print (auto[-2])
a=f"{auto[3]} = "
b=auto.index('zigool')
c=dict(b)
print (a, c)
d={1:'a', 2:'b'}
e=type(d)
print(e)