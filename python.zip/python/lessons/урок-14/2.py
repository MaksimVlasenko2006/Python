num = (132, 10, 15, 45, 10, 10, 16)
a=min(num)
b=max(num)
s=0
for i in num:
    print(i)
    s+=i
print(a + b)