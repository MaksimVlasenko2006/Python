user_name = {}

user_name["user_1"] = "Den"
user_name["user_2"] = "Illysha"
print(user_name)
print(user_name["user_2"])