favorite_languages = { 
  'user_0': 'python', 
  'user_1': 'js', 
  'user_2': 'php', 
  'user_3': 'python', 
  }
for name, language in favorite_languages.items(): 
  print(f"{name.title()}'s favorite language is {language.title()}.")