alien_0 = {'color': 'green', 'points': 5} 

item_0 = alien_0['points']
print(f"Ты виграл на {item_0}-м уровне")