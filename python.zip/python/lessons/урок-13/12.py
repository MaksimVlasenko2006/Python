favorite_languages = { 
  'user_0': 'python', 
  'user_1': 'js', 
  'user_2': 'php', 
  'user_3': 'python', 
}
for name in favorite_languages.keys(): 
  print(name.title())