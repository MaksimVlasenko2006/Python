favorite_languages = { 
  'user_0': 'python', 
  'user_1': 'js', 
  'user_2': 'php', 
  'user_3': 'python', 
  }


 
for language in favorite_languages.values(): 
  print(language.title())