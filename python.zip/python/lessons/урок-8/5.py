k = int(input('Введите k:   '))
i = 1
p=1
while i<=k:
	p*=i
	i+=1
print(p)