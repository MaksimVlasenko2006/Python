a = int(input('Введите диапазон   '))
y=1
while y <=a:
	print(f'y = {y**2}')
	y+=1
