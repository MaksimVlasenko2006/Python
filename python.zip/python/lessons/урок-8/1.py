a = int(input('Введите диапазон   '))
for i in range(1,a+1):
    print(f'y = {i**2}')
