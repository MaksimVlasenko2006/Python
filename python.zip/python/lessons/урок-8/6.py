a = int(input('Введите число:   '))
i = 0

while a>0:
	a= a//10
	i+=1
	print(i)