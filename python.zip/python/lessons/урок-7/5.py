n = int(input('Введите число:   '))
b=0
for i in range(1,n+1,):
	b+=i
print(f'SUM = {b}') 