import os
os.system('cls||clear')
text = str(input('Введите слово:  '))
a=0
for i in text:
	print(i,end=" ")
	a+=1
	print(a)