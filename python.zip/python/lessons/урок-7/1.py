a=str(input('Word: '))
b=0
for i in a:
     print(i, end=' ', '\n')
     b+=1
print(b,'Symvols')