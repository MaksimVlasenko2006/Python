text = ['Привет','БМВ','ШОК','ГУГЛ','ЯНДЕКС']
for i in range(5):
	print(f'\n{text[i]}')