def summa(a, b):
	global c
	c = a+b
summa(2,3)
print(c)