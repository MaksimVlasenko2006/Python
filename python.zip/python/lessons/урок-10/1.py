def greet_user():
	print('Hello')
greet_user()