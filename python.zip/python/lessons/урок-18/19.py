import random
a=[random.randint(0,10000000000) for i in range(7)]
print (a)
