a=[3 for i in range(9)]
b=[0 for i in range(7)]
c=[i*5 for i in "HELLO"]
print (a)
print (c)

