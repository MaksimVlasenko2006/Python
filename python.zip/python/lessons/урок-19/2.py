import random
a = [random.randint(5,10) for i in range(7)]
print(a)