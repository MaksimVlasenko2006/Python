a = [0 for i in range(7)]
b = [3 for i in range(9)]
c = [i*5 for i in 'hello']
print(a)
print(b)
print(c)