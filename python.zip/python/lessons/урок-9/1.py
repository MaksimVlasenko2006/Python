while True:
	name = input('Введите имя:   ')
	if name == 'хватит':
		break
	print(f'Привет, {name}')