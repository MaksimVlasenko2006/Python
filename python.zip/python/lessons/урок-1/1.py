print('Hello World')
