julia=['sushi','pizza','cake']
teacher=julia[:]
print(julia)
print(teacher)
a=str(input("a="))
teacher.append(a)
print(teacher)
for i in teacher:
    print(i)
