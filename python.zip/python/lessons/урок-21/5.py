list1=["user_0","user_1","user_2"]
list2=[]
while list1:
    i=list1.pop()
    print(i)
    list2.append(i)
print(list2)
