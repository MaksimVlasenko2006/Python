dict={'a':2,'b':4,'c':6,'d':8}
for i in dict.values():
    if i>2:
        print(i)
