a=int(input('a='))
b=int(input('b='))
print('delenie', a/b)
print('delenie s ostatkom', a//b)
print('delenie bez ostatka', a%b)

a=float(input('a='))
b=float(input('b='))
print('a>b'a>b)
print('a<b'a<b)
print('a=b'a==b)

name=str(input('your name: '))
print('Я ', name, ' програмист Ucode')

