#mashine=['tesla', 'mersedess', 'bmw', 'wolksvagen', 'ferrari', 'ford']
#message = f'Хотите ли вы эту машину {mashine[1].title()}?'
#print(message)

#family=['mother', 'father', 'sister']
#message1 = f'Приглашаем вас на день рождения к {family[0].title()}?'
#message2 = f'Приглашаем вас на день рождения к {family[1].title()}?'
#message3 = f'Приглашаем вас на день рождения к {family[2].title()}?'
#print(message1)
#print(message2)
#print(message3)

mashine=['tesla', 'mersedess', 'bmw', 'wolksvagen', 'ferrari', 'ford']
mashine[0]='lexus'
mashine.append('honda')
print(mashine)
