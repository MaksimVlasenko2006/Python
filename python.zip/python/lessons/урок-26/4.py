import math
class Circle:
    def __init__(self,r):
        self.r=r
    def len(self):
        return math.pi*(self.r**2)
    def s(self):
        return 2 * math.pi*self.r
r=int(input("r="))
p1=Circle
print(

p2=Pyhton()
p2.info()
p3=Pyhton()
p3.info()
