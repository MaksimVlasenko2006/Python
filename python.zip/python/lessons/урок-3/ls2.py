mashin = ['tesla','bmw','suzuki','mercedes']
#message = f"Хотите ли вы эту машину {mashin[1].title()}?"
#print(message)
#family = ['Илюша','Максим','Дэвид']
#message = f'{family[0]}, приглашаю тебя на мой др!'
#message1 = f'{family[1]}, приглашаю тебя на мой др!'
#message2 = f'{family[2]}, приглашаю тебя на мой др!'
#print("\n",message,"\n",message1,"\n",message2)
mashin[0]= 'lexus'
mashin.append('honda')
print(mashin)
