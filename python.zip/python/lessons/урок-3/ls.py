#a = int(input('Введите 1-ое число '))
#b = int(input('Введите 2-е число '))
#print("Остаток: ", a%b,"Целое: ", a//b)
#print('Первое число больше второго. ',a>b,'\nПервое число меньше второго. ',a<b,'\nПервое число равно второму. ',a==b)
#name = input('Введи имя \n')
#print('Я, ' + name + ', програмист ucode')
mashin=['tesla','bmw','suzuki']
print(mashin[-1].title())
